# Student ID Record Manager

A polished desktop student-record application based on the supplied DataSpark Challenge brief.

## Features
- Dashboard with total students, average marks, attendance and department count
- Add, edit (double-click a row), search and delete student records
- Input validation for roll number, name, year, email, phone, marks and attendance
- Automatic local JSON persistence (`students.json`)
- CSV import with row-by-row validation and error reporting
- CSV export and text summary report
- Analytics: pass rate, attendance warnings, averages and department distribution
- Built with Python standard library only (Tkinter, csv, json, pathlib, datetime)

## Run on Windows
1. Install Python 3.10 or newer from https://www.python.org/downloads/
2. Extract this ZIP file.
3. Open the extracted folder.
4. Click the address bar in File Explorer, type `cmd`, and press Enter.
5. Run:

   `python main.py`

If `python` is not recognized, try `py main.py`.

Tkinter is included with most standard Windows Python installations.

## Data
The app creates `students.json` in the same folder after the first save. Keep this file to retain records.
Use **Import CSV** to load your own dataset. The included `sample_students.csv` has 40 demo records.

## CSV columns
`roll_no,name,department,year,email,phone,attendance,marks`

## Demo flow
1. Open Dashboard.
2. Select Add Student and enter a new record.
3. Try an invalid year or attendance value to demonstrate validation.
4. Search by roll number/name/department.
5. Double-click a row to edit; select a row and choose Delete selected to remove it.
6. Import/export CSV and view Analytics.
