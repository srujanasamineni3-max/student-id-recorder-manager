"""
STUDENT ID RECORD MANAGER
A polished, zero-dependency desktop application built with Python + Tkinter.
Run: python main.py
Data is stored locally in students.json; CSV import/export is supported.
"""
from __future__ import annotations

import csv
import json
import re
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from datetime import datetime
from collections import Counter

APP_DIR = Path(__file__).resolve().parent
DATA_FILE = APP_DIR / "students.json"

BG = "#F3F6FC"
NAVY = "#172554"
BLUE = "#4263EB"
CYAN = "#0EA5A4"
WHITE = "#FFFFFF"
TEXT = "#1E293B"
MUTED = "#64748B"
BORDER = "#E2E8F0"
GREEN = "#16A34A"
ORANGE = "#D97706"
RED = "#DC2626"

FIELDS = ["roll_no", "name", "department", "year", "email", "phone", "attendance", "marks", "status"]


def clean(value):
    return str(value or "").strip()


def validate_record(data, existing, original_roll=None):
    roll = clean(data.get("roll_no")).upper()
    name = clean(data.get("name"))
    dept = clean(data.get("department")).upper()
    year = clean(data.get("year"))
    email = clean(data.get("email"))
    phone = clean(data.get("phone"))
    attendance = clean(data.get("attendance"))
    marks = clean(data.get("marks"))

    if not re.fullmatch(r"[A-Z0-9-]{3,20}", roll):
        raise ValueError("Roll number must be 3–20 characters (letters, numbers or hyphens).")
    if any(s["roll_no"].upper() == roll and s["roll_no"] != original_roll for s in existing):
        raise ValueError("That roll number already exists.")
    if len(name) < 2 or not re.fullmatch(r"[A-Za-z .'-]+", name):
        raise ValueError("Enter a valid student name (letters and basic punctuation only).")
    if not dept:
        raise ValueError("Department cannot be empty.")
    if year not in {"1", "2", "3", "4"}:
        raise ValueError("Year must be 1, 2, 3 or 4.")
    if email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        raise ValueError("Enter a valid email address or leave it blank.")
    if phone and not re.fullmatch(r"[0-9+() -]{7,18}", phone):
        raise ValueError("Phone number must contain 7–18 valid characters.")
    try:
        attendance_value = float(attendance)
        marks_value = float(marks)
    except ValueError:
        raise ValueError("Attendance and marks must be numbers.")
    if not 0 <= attendance_value <= 100:
        raise ValueError("Attendance must be between 0 and 100.")
    if not 0 <= marks_value <= 100:
        raise ValueError("Marks must be between 0 and 100.")

    return {
        "roll_no": roll, "name": name.title(), "department": dept,
        "year": int(year), "email": email, "phone": phone,
        "attendance": round(attendance_value, 2), "marks": round(marks_value, 2),
        "status": "Active", "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M")
    }


class StudentManager(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Student ID Record Manager")
        self.geometry("1220x760")
        self.minsize(1000, 650)
        self.configure(bg=BG)
        self.records = self.load_data()
        self.filtered = list(self.records)
        self.current_page = "Dashboard"
        self.setup_style()
        self.build_shell()
        self.show_page("Dashboard")

    def setup_style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Treeview", background=WHITE, foreground=TEXT, rowheight=36,
                        fieldbackground=WHITE, borderwidth=0, font=("Segoe UI", 10))
        style.configure("Treeview.Heading", background="#EEF2FF", foreground=NAVY,
                        relief="flat", font=("Segoe UI Semibold", 9))
        style.map("Treeview", background=[("selected", "#DBEAFE")],
                  foreground=[("selected", NAVY)])
        style.configure("TCombobox", padding=7, font=("Segoe UI", 10))

    def load_data(self):
        if not DATA_FILE.exists():
            return []
        try:
            data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except (json.JSONDecodeError, OSError):
            messagebox.showwarning("Storage notice",
                "The saved data file could not be read. A fresh in-memory list will be opened.")
            return []

    def save_data(self):
        temp = DATA_FILE.with_suffix(".tmp")
        temp.write_text(json.dumps(self.records, indent=2), encoding="utf-8")
        temp.replace(DATA_FILE)

    def build_shell(self):
        self.sidebar = tk.Frame(self, bg=NAVY, width=235)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        brand = tk.Frame(self.sidebar, bg=NAVY)
        brand.pack(fill="x", padx=22, pady=(28, 34))
        tk.Label(brand, text="✦  CAMPUS DESK", bg=NAVY, fg="#A5B4FC",
                 font=("Segoe UI Semibold", 10)).pack(anchor="w")
        tk.Label(brand, text="Student Records", bg=NAVY, fg=WHITE,
                 font=("Segoe UI", 19, "bold")).pack(anchor="w", pady=(9, 2))
        tk.Label(brand, text="MANAGEMENT SYSTEM", bg=NAVY, fg="#94A3B8",
                 font=("Segoe UI", 8, "bold")).pack(anchor="w")

        self.nav_buttons = {}
        for label, symbol in [("Dashboard", "▦"), ("All Students", "▤"),
                              ("Add Student", "＋"), ("Analytics", "◷")]:
            btn = tk.Button(self.sidebar, text=f"   {symbol}    {label}", anchor="w",
                command=lambda x=label: self.show_page(x), bd=0, relief="flat",
                bg=NAVY, fg="#CBD5E1", activebackground="#263B78",
                activeforeground=WHITE, font=("Segoe UI Semibold", 10),
                padx=18, pady=13, cursor="hand2")
            btn.pack(fill="x", padx=12, pady=3)
            self.nav_buttons[label] = btn

        tk.Frame(self.sidebar, bg="#334477", height=1).pack(fill="x", padx=20, pady=25)
        tk.Label(self.sidebar, text="LOCAL • PRIVATE • SIMPLE", bg=NAVY,
                 fg="#94A3B8", font=("Segoe UI", 8, "bold")).pack(side="bottom", pady=22)

        self.main = tk.Frame(self, bg=BG)
        self.main.pack(side="left", fill="both", expand=True)
        self.header = tk.Frame(self.main, bg=BG)
        self.header.pack(fill="x", padx=32, pady=(25, 18))
        self.page_title = tk.Label(self.header, text="", bg=BG, fg=NAVY,
                                   font=("Segoe UI", 22, "bold"))
        self.page_title.pack(side="left")
        self.header_right = tk.Frame(self.header, bg=BG)
        self.header_right.pack(side="right")
        tk.Label(self.header_right, text="●  SYSTEM READY", bg=BG, fg=GREEN,
                 font=("Segoe UI", 9, "bold")).pack(side="right", padx=8)

        self.content = tk.Frame(self.main, bg=BG)
        self.content.pack(fill="both", expand=True, padx=32, pady=(0, 25))
        self.footer = tk.Label(self.main, text="Student ID Record Manager  •  Data saved on this computer",
                               bg=BG, fg="#94A3B8", font=("Segoe UI", 8))
        self.footer.pack(side="bottom", pady=(0, 10))

    def clear_content(self):
        for w in self.content.winfo_children():
            w.destroy()
        for name, btn in self.nav_buttons.items():
            btn.configure(bg="#263B78" if name == self.current_page else NAVY,
                          fg=WHITE if name == self.current_page else "#CBD5E1")

    def show_page(self, page):
        self.current_page = page
        self.clear_content()
        self.page_title.configure(text=page)
        if page == "Dashboard":
            self.dashboard()
        elif page == "All Students":
            self.students_page()
        elif page == "Add Student":
            self.student_form()
        elif page == "Analytics":
            self.analytics_page()

    def card(self, parent, title, value, subtitle, accent=BLUE):
        frame = tk.Frame(parent, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
        tk.Frame(frame, bg=accent, height=4).pack(fill="x")
        body = tk.Frame(frame, bg=WHITE)
        body.pack(fill="both", expand=True, padx=18, pady=15)
        tk.Label(body, text=title.upper(), bg=WHITE, fg=MUTED,
                 font=("Segoe UI", 8, "bold")).pack(anchor="w")
        tk.Label(body, text=str(value), bg=WHITE, fg=NAVY,
                 font=("Segoe UI", 25, "bold")).pack(anchor="w", pady=(5, 1))
        tk.Label(body, text=subtitle, bg=WHITE, fg=MUTED,
                 font=("Segoe UI", 9)).pack(anchor="w")
        return frame

    def section(self, parent, title, action=None, command=None):
        bar = tk.Frame(parent, bg=BG)
        bar.pack(fill="x", pady=(18, 10))
        tk.Label(bar, text=title, bg=BG, fg=NAVY,
                 font=("Segoe UI Semibold", 13)).pack(side="left")
        if action:
            tk.Button(bar, text=action, command=command, bg=BG, fg=BLUE, bd=0,
                      font=("Segoe UI Semibold", 9), cursor="hand2").pack(side="right")

    def dashboard(self):
        tk.Label(self.content, text="Welcome back! Here’s your campus records overview.",
                 bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w", pady=(0, 17))
        total = len(self.records)
        avg = sum(float(r.get("marks", 0)) for r in self.records) / total if total else 0
        attendance = sum(float(r.get("attendance", 0)) for r in self.records) / total if total else 0
        depts = len(set(r.get("department", "") for r in self.records))
        stats = tk.Frame(self.content, bg=BG)
        stats.pack(fill="x")
        for i, c in enumerate([
            self.card(stats, "Total students", total, "Registered records", BLUE),
            self.card(stats, "Average marks", f"{avg:.1f}%", "Across all students", CYAN),
            self.card(stats, "Avg. attendance", f"{attendance:.1f}%", "Attendance overview", GREEN),
            self.card(stats, "Departments", depts, "Unique departments", ORANGE)
        ]):
            c.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 10, 0))
            stats.grid_columnconfigure(i, weight=1, uniform="cards")

        self.section(self.content, "Recently added students", "View all students →",
                     lambda: self.show_page("All Students"))
        panel = tk.Frame(self.content, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
        panel.pack(fill="both", expand=True)
        self.make_table(panel, self.records[-6:][::-1], compact=True)
        if not self.records:
            tk.Label(panel, text="No records yet. Select “Add Student” to create your first entry.",
                     bg=WHITE, fg=MUTED, font=("Segoe UI", 10)).pack(pady=25)

    def make_table(self, parent, rows, compact=False):
        cols = ("roll_no", "name", "department", "year", "marks", "attendance")
        headings = ("ROLL NUMBER", "STUDENT NAME", "DEPARTMENT", "YEAR", "MARKS", "ATTENDANCE")
        wrap = tk.Frame(parent, bg=WHITE)
        wrap.pack(fill="both", expand=True, padx=12, pady=12)
        tree = ttk.Treeview(wrap, columns=cols, show="headings", height=7 if compact else 13)
        widths = (135, 190, 125, 60, 90, 110)
        for col, heading, width in zip(cols, headings, widths):
            tree.heading(col, text=heading)
            tree.column(col, width=width, anchor="w" if col in ("roll_no", "name", "department") else "center")
        for r in rows:
            tree.insert("", "end", values=(r.get("roll_no"), r.get("name"), r.get("department"),
                r.get("year"), f'{float(r.get("marks", 0)):.1f}%', f'{float(r.get("attendance", 0)):.1f}%'))
        tree.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(wrap, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        return tree

    def students_page(self):
        top = tk.Frame(self.content, bg=BG)
        top.pack(fill="x", pady=(0, 14))
        self.search_var = tk.StringVar()
        search = tk.Entry(top, textvariable=self.search_var, font=("Segoe UI", 10),
                          bg=WHITE, fg=TEXT, relief="flat", highlightthickness=1,
                          highlightbackground=BORDER, highlightcolor=BLUE)
        search.pack(side="left", fill="x", expand=True, ipady=10, padx=(0, 10))
        search.insert(0, "Search by roll number, name or department...")
        search.bind("<FocusIn>", lambda e: search.delete(0, "end") if search.get().startswith("Search by") else None)
        search.bind("<KeyRelease>", lambda e: self.refresh_student_table())
        tk.Button(top, text="＋  Add Student", command=lambda: self.show_page("Add Student"),
                  bg=BLUE, fg=WHITE, bd=0, padx=17, pady=10,
                  font=("Segoe UI Semibold", 9), cursor="hand2").pack(side="right")
        actions = tk.Frame(self.content, bg=BG)
        actions.pack(fill="x", pady=(0, 10))
        tk.Button(actions, text="Import CSV", command=self.import_csv, bg="#E0E7FF", fg=NAVY,
                  bd=0, padx=13, pady=8, cursor="hand2").pack(side="left", padx=(0, 8))
        tk.Button(actions, text="Export CSV", command=self.export_csv, bg="#CCFBF1", fg="#115E59",
                  bd=0, padx=13, pady=8, cursor="hand2").pack(side="left")
        tk.Button(actions, text="Delete selected", command=self.delete_selected, bg="#FEE2E2", fg=RED,
                  bd=0, padx=13, pady=8, cursor="hand2").pack(side="right")
        self.table_panel = tk.Frame(self.content, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
        self.table_panel.pack(fill="both", expand=True)
        self.refresh_student_table()

    def refresh_student_table(self):
        if not hasattr(self, "table_panel") or not self.table_panel.winfo_exists():
            return
        for w in self.table_panel.winfo_children():
            w.destroy()
        query = self.search_var.get().strip().lower()
        rows = [r for r in self.records if query in " ".join(str(r.get(k, "")) for k in ("roll_no", "name", "department")).lower()]
        self.active_tree = self.make_table(self.table_panel, rows)
        self.active_tree.bind("<Double-1>", self.edit_selected)

    def selected_record(self):
        selected = self.active_tree.selection()
        if not selected:
            messagebox.showinfo("Select a student", "Choose a student row first.")
            return None
        roll = self.active_tree.item(selected[0], "values")[0]
        return next((r for r in self.records if r["roll_no"] == roll), None)

    def delete_selected(self):
        r = self.selected_record()
        if r and messagebox.askyesno("Confirm delete", f"Delete record for {r['name']} ({r['roll_no']})?"):
            self.records.remove(r)
            self.save_data()
            self.refresh_student_table()

    def edit_selected(self, event=None):
        r = self.selected_record()
        if r:
            self.student_form(r)

    def student_form(self, record=None):
        editing = record is not None
        tk.Label(self.content, text="Enter the details below. Fields are checked before saving.",
                 bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w", pady=(0, 16))
        panel = tk.Frame(self.content, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
        panel.pack(fill="x", anchor="n")
        form = tk.Frame(panel, bg=WHITE)
        form.pack(fill="x", padx=24, pady=22)
        variables = {}
        fields = [
            ("Roll number *", "roll_no", "e.g. 26CSIT001"),
            ("Student name *", "name", "Full name"),
            ("Department *", "department", "e.g. CSIT"),
            ("Year *", "year", "1, 2, 3 or 4"),
            ("Email", "email", "student@example.com"),
            ("Phone", "phone", "Optional contact number"),
            ("Attendance (%) *", "attendance", "0 to 100"),
            ("Marks (%) *", "marks", "0 to 100")
        ]
        for i, (label, key, hint) in enumerate(fields):
            row, col = divmod(i, 2)
            cell = tk.Frame(form, bg=WHITE)
            cell.grid(row=row, column=col, sticky="ew", padx=(0 if col == 0 else 18, 0), pady=9)
            tk.Label(cell, text=label, bg=WHITE, fg=TEXT,
                     font=("Segoe UI Semibold", 9)).pack(anchor="w", pady=(0, 6))
            var = tk.StringVar(value=str(record.get(key, "")) if record else "")
            variables[key] = var
            ent = tk.Entry(cell, textvariable=var, bg="#F8FAFC", fg=TEXT, relief="flat",
                           highlightthickness=1, highlightbackground=BORDER,
                           highlightcolor=BLUE, font=("Segoe UI", 10))
            ent.pack(fill="x", ipady=9)
            if not record and key == "year":
                var.set("1")
            if not record and key in ("attendance", "marks"):
                var.set("0")
            form.grid_columnconfigure(col, weight=1)

        buttons = tk.Frame(panel, bg=WHITE)
        buttons.pack(fill="x", padx=24, pady=(0, 22))
        def save():
            try:
                data = validate_record({k: v.get() for k, v in variables.items()},
                                       self.records, record["roll_no"] if record else None)
                if editing:
                    idx = self.records.index(record)
                    self.records[idx] = data
                else:
                    self.records.append(data)
                self.save_data()
                messagebox.showinfo("Saved", "Student record saved successfully.")
                self.show_page("All Students")
            except ValueError as exc:
                messagebox.showerror("Check the details", str(exc))
        tk.Button(buttons, text="Save student  →", command=save, bg=BLUE, fg=WHITE,
                  bd=0, padx=20, pady=11, font=("Segoe UI Semibold", 9),
                  cursor="hand2").pack(side="left")
        tk.Button(buttons, text="Cancel", command=lambda: self.show_page("All Students" if editing else "Dashboard"),
                  bg="#F1F5F9", fg=TEXT, bd=0, padx=20, pady=11,
                  font=("Segoe UI Semibold", 9), cursor="hand2").pack(side="left", padx=10)

    def analytics_page(self):
        total = len(self.records)
        avg_marks = sum(float(r.get("marks", 0)) for r in self.records) / total if total else 0
        avg_att = sum(float(r.get("attendance", 0)) for r in self.records) / total if total else 0
        passed = sum(float(r.get("marks", 0)) >= 40 for r in self.records)
        low_att = sum(float(r.get("attendance", 0)) < 75 for r in self.records)
        tk.Label(self.content, text="A quick snapshot of academic records and student status.",
                 bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w", pady=(0, 17))
        grid = tk.Frame(self.content, bg=BG)
        grid.pack(fill="x")
        cards = [
            self.card(grid, "Pass rate", f"{(passed/total*100 if total else 0):.1f}%", f"{passed} students with marks ≥ 40", GREEN),
            self.card(grid, "Below attendance target", low_att, "Students under 75% attendance", ORANGE),
            self.card(grid, "Average marks", f"{avg_marks:.1f}%", "Overall academic average", BLUE),
            self.card(grid, "Average attendance", f"{avg_att:.1f}%", "Overall attendance average", CYAN)
        ]
        for i, c in enumerate(cards):
            c.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 10, 0))
            grid.grid_columnconfigure(i, weight=1, uniform="analytics")
        self.section(self.content, "Department distribution")
        panel = tk.Frame(self.content, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
        panel.pack(fill="x")
        counts = Counter(r.get("department", "Other") for r in self.records)
        if not counts:
            tk.Label(panel, text="Add student records to see department analytics.",
                     bg=WHITE, fg=MUTED, font=("Segoe UI", 10)).pack(pady=24)
        for dept, count in counts.most_common():
            line = tk.Frame(panel, bg=WHITE)
            line.pack(fill="x", padx=20, pady=10)
            tk.Label(line, text=dept, bg=WHITE, fg=TEXT, width=12, anchor="w",
                     font=("Segoe UI Semibold", 10)).pack(side="left")
            track = tk.Frame(line, bg="#E2E8F0", height=10)
            track.pack(side="left", fill="x", expand=True, padx=10)
            fill = tk.Frame(track, bg=BLUE, height=10, width=max(8, int(400*count/max(counts.values()))))
            fill.pack(side="left")
            tk.Label(line, text=str(count), bg=WHITE, fg=MUTED, width=4,
                     font=("Segoe UI", 9)).pack(side="right")
        tk.Button(self.content, text="Export summary report", command=self.export_report,
                  bg=BLUE, fg=WHITE, bd=0, padx=18, pady=11,
                  font=("Segoe UI Semibold", 9), cursor="hand2").pack(anchor="w", pady=18)

    def import_csv(self):
        path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if not path:
            return
        added, errors = 0, []
        try:
            with open(path, newline="", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                for line, row in enumerate(reader, start=2):
                    try:
                        data = validate_record(row, self.records)
                        self.records.append(data)
                        added += 1
                    except ValueError as e:
                        errors.append(f"Row {line}: {e}")
            self.save_data()
            self.refresh_student_table()
            msg = f"Imported {added} record(s)."
            if errors:
                msg += "\n\nSkipped rows:\n" + "\n".join(errors[:8])
                if len(errors) > 8:
                    msg += f"\n…and {len(errors)-8} more."
            messagebox.showinfo("Import complete", msg)
        except (OSError, csv.Error) as e:
            messagebox.showerror("Import failed", str(e))

    def export_csv(self):
        path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=FIELDS)
                writer.writeheader()
                writer.writerows(self.records)
            messagebox.showinfo("Export complete", f"CSV saved to:\n{path}")
        except OSError as e:
            messagebox.showerror("Export failed", str(e))

    def export_report(self):
        path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text report", "*.txt")])
        if not path:
            return
        total = len(self.records)
        avg_m = sum(float(r.get("marks", 0)) for r in self.records) / total if total else 0
        avg_a = sum(float(r.get("attendance", 0)) for r in self.records) / total if total else 0
        depts = Counter(r.get("department", "Other") for r in self.records)
        lines = ["STUDENT ID RECORD MANAGER", "=" * 34,
                 f"Generated: {datetime.now():%d %b %Y, %I:%M %p}",
                 f"Total students: {total}", f"Average marks: {avg_m:.2f}%",
                 f"Average attendance: {avg_a:.2f}%", "",
                 "DEPARTMENT SUMMARY", "-" * 20]
        lines += [f"{d}: {n}" for d, n in depts.items()]
        lines += ["", "STUDENT RECORDS", "-" * 20]
        lines += [f"{r['roll_no']} | {r['name']} | {r['department']} | Year {r['year']} | Marks {r['marks']}% | Attendance {r['attendance']}%" for r in self.records]
        Path(path).write_text("\n".join(lines), encoding="utf-8")
        messagebox.showinfo("Report exported", f"Summary report saved to:\n{path}")


if __name__ == "__main__":
    app = StudentManager()
    app.mainloop()
